package com.silenthong.kdreader;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * 考点阅读器 - 考点发送界面
 * 输入考点标题和内容，发送到手环
 */
public class SendActivity extends AppCompatActivity {

    private WearableManager wearableManager;

    private EditText editTitle;
    private EditText editContent;
    private Button btnSend;
    private Button btnBack;
    private TextView textProgress;
    private ProgressBar progressBar;
    private TextView textStatus;

    private boolean isSending = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send);

        wearableManager = WearableManager.getInstance(this);

        initViews();
        initListeners();

        // 检查连接状态
        if (!wearableManager.isConnected()) {
            textStatus.setText(R.string.status_disconnected);
            textStatus.setTextColor(getResources().getColor(R.color.accent_red));
            btnSend.setEnabled(false);
        } else {
            textStatus.setText(R.string.status_connected);
            textStatus.setTextColor(getResources().getColor(R.color.accent_green));
        }
    }

    private void initViews() {
        editTitle = findViewById(R.id.editTitle);
        editContent = findViewById(R.id.editContent);
        btnSend = findViewById(R.id.btnSend);
        btnBack = findViewById(R.id.btnBack);
        textProgress = findViewById(R.id.textProgress);
        progressBar = findViewById(R.id.progressBar);
        textStatus = findViewById(R.id.textStatus);

        progressBar.setVisibility(View.GONE);
        textProgress.setVisibility(View.GONE);
    }

    private void initListeners() {
        btnBack.setOnClickListener(v -> {
            if (!isSending) {
                finish();
            }
        });

        btnSend.setOnClickListener(v -> {
            if (isSending) return;

            String title = editTitle.getText().toString().trim();
            String content = editContent.getText().toString().trim();

            if (content.isEmpty()) {
                editContent.setError("请输入考点内容");
                return;
            }

            sendContent(title, content);
        });

        // 实时字数统计
        editContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                int len = s.length();
                textProgress.setVisibility(len > 0 ? View.VISIBLE : View.GONE);
                textProgress.setText("内容长度: " + len + " 字");
            }
        });
    }

    private void sendContent(String title, String content) {
        isSending = true;
        btnSend.setEnabled(false);
        btnBack.setEnabled(false);
        editTitle.setEnabled(false);
        editContent.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        textStatus.setText(R.string.status_sending);
        textStatus.setTextColor(getResources().getColor(R.color.accent_orange));

        wearableManager.sendContent(title, content, new WearableManager.SendCallback() {
            @Override
            public void onProgress(int current, int total, String message) {
                runOnUiThread(() -> {
                    progressBar.setMax(total);
                    progressBar.setProgress(current);
                    textProgress.setText(message);
                });
            }

            @Override
            public void onSuccess() {
                runOnUiThread(() -> {
                    isSending = false;
                    btnSend.setEnabled(true);
                    btnBack.setEnabled(true);
                    editTitle.setEnabled(true);
                    editContent.setEnabled(true);
                    progressBar.setVisibility(View.GONE);
                    textStatus.setText(R.string.status_sent);
                    textStatus.setTextColor(getResources().getColor(R.color.accent_green));
                    textProgress.setText("发送成功！请在手环端查看");

                    // 清空输入
                    editTitle.setText("");
                    editContent.setText("");
                });
            }

            @Override
            public void onFailure(String message) {
                runOnUiThread(() -> {
                    isSending = false;
                    btnSend.setEnabled(true);
                    btnBack.setEnabled(true);
                    editTitle.setEnabled(true);
                    editContent.setEnabled(true);
                    progressBar.setVisibility(View.GONE);
                    textStatus.setText(R.string.status_failed);
                    textStatus.setTextColor(getResources().getColor(R.color.accent_red));
                    textProgress.setText("发送失败: " + message);
                });
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!isSending) {
            super.onBackPressed();
        }
    }
}
