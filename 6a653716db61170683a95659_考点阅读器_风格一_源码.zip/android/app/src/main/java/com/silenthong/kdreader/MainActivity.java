package com.silenthong.kdreader;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.xiaomi.xms.wearable.node.Node;

/**
 * 考点阅读器 - 安卓端主界面
 * 管理手环连接状态，提供考点发送入口
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private WearableManager wearableManager;

    private TextView textStatus;
    private TextView textDeviceName;
    private Button btnConnect;
    private Button btnSend;
    private Button btnLaunchApp;
    private Button btnCheckApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wearableManager = WearableManager.getInstance(this);

        initViews();
        initListeners();

        // 注册服务连接监听
        wearableManager.registerServiceListener(new WearableManager.ConnectionCallback() {
            @Override
            public void onDeviceFound(Node node) {
                runOnUiThread(() -> {
                    textStatus.setText(R.string.status_connected);
                    textStatus.setTextColor(getResources().getColor(R.color.accent_green));
                    textDeviceName.setText(node.name);
                    btnSend.setEnabled(true);
                    btnLaunchApp.setEnabled(true);
                    btnCheckApp.setEnabled(true);
                });
            }

            @Override
            public void onNoDevice() {
                runOnUiThread(() -> {
                    textStatus.setText(R.string.status_no_device);
                    textStatus.setTextColor(getResources().getColor(R.color.accent_red));
                    textDeviceName.setText("");
                    btnSend.setEnabled(false);
                    btnLaunchApp.setEnabled(false);
                    btnCheckApp.setEnabled(false);
                });
            }

            @Override
            public void onServiceConnected() {
                runOnUiThread(() -> {
                    // 服务连接后自动搜索设备
                    wearableManager.getConnectedDevice(this);
                });
            }

            @Override
            public void onServiceDisconnected() {
                runOnUiThread(() -> {
                    textStatus.setText(R.string.status_disconnected);
                    textStatus.setTextColor(getResources().getColor(R.color.text_hint));
                    textDeviceName.setText("");
                    btnSend.setEnabled(false);
                    btnLaunchApp.setEnabled(false);
                    btnCheckApp.setEnabled(false);
                });
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    textStatus.setText("错误: " + message);
                    textStatus.setTextColor(getResources().getColor(R.color.accent_red));
                });
            }
        });

        // 初始搜索设备
        wearableManager.getConnectedDevice(new WearableManager.ConnectionCallback() {
            @Override
            public void onDeviceFound(Node node) {
                runOnUiThread(() -> {
                    textStatus.setText(R.string.status_connected);
                    textStatus.setTextColor(getResources().getColor(R.color.accent_green));
                    textDeviceName.setText(node.name);
                    btnSend.setEnabled(true);
                    btnLaunchApp.setEnabled(true);
                    btnCheckApp.setEnabled(true);
                    // 检查权限
                    checkPermission();
                });
            }

            @Override
            public void onNoDevice() {
                runOnUiThread(() -> {
                    textStatus.setText(R.string.status_no_device);
                    textStatus.setTextColor(getResources().getColor(R.color.accent_red));
                    textDeviceName.setText("");
                });
            }

            @Override
            public void onServiceConnected() {}

            @Override
            public void onServiceDisconnected() {}

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    textStatus.setText("错误: " + message);
                    textStatus.setTextColor(getResources().getColor(R.color.accent_red));
                });
            }
        });
    }

    private void initViews() {
        textStatus = findViewById(R.id.textStatus);
        textDeviceName = findViewById(R.id.textDeviceName);
        btnConnect = findViewById(R.id.btnConnect);
        btnSend = findViewById(R.id.btnSend);
        btnLaunchApp = findViewById(R.id.btnLaunchApp);
        btnCheckApp = findViewById(R.id.btnCheckApp);

        btnSend.setEnabled(false);
        btnLaunchApp.setEnabled(false);
        btnCheckApp.setEnabled(false);
    }

    private void initListeners() {
        btnConnect.setOnClickListener(v -> {
            textStatus.setText(R.string.status_connecting);
            textStatus.setTextColor(getResources().getColor(R.color.accent_orange));
            wearableManager.getConnectedDevice(new WearableManager.ConnectionCallback() {
                @Override
                public void onDeviceFound(Node node) {
                    runOnUiThread(() -> {
                        textStatus.setText(R.string.status_connected);
                        textStatus.setTextColor(getResources().getColor(R.color.accent_green));
                        textDeviceName.setText(node.name);
                        btnSend.setEnabled(true);
                        btnLaunchApp.setEnabled(true);
                        btnCheckApp.setEnabled(true);
                        checkPermission();
                    });
                }

                @Override
                public void onNoDevice() {
                    runOnUiThread(() -> {
                        textStatus.setText(R.string.status_no_device);
                        textStatus.setTextColor(getResources().getColor(R.color.accent_red));
                    });
                }

                @Override
                public void onServiceConnected() {}

                @Override
                public void onServiceDisconnected() {}

                @Override
                public void onError(String message) {
                    runOnUiThread(() -> {
                        textStatus.setText("错误: " + message);
                        textStatus.setTextColor(getResources().getColor(R.color.accent_red));
                    });
                }
            });
        });

        btnSend.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SendActivity.class);
            startActivity(intent);
        });

        btnLaunchApp.setOnClickListener(v -> {
            wearableManager.launchWearApp(new WearableManager.ConnectionCallback() {
                @Override
                public void onDeviceFound(Node node) {}

                @Override
                public void onNoDevice() {}

                @Override
                public void onServiceConnected() {}

                @Override
                public void onServiceDisconnected() {}

                @Override
                public void onError(String message) {
                    runOnUiThread(() -> {
                        textStatus.setText("打开手环应用失败: " + message);
                    });
                }
            });
        });

        btnCheckApp.setOnClickListener(v -> {
            wearableManager.checkAppInstalled(new WearableManager.AppCheckCallback() {
                @Override
                public void onInstalled(boolean installed) {
                    runOnUiThread(() -> {
                        if (installed) {
                            textStatus.setText("手环端应用已安装");
                            textStatus.setTextColor(getResources().getColor(R.color.accent_green));
                        } else {
                            textStatus.setText(R.string.status_app_not_installed);
                            textStatus.setTextColor(getResources().getColor(R.color.accent_orange));
                        }
                    });
                }

                @Override
                public void onError(String message) {
                    runOnUiThread(() -> {
                        textStatus.setText("检查失败: " + message);
                        textStatus.setTextColor(getResources().getColor(R.color.accent_red));
                    });
                }
            });
        });
    }

    private void checkPermission() {
        wearableManager.checkPermission(new WearableManager.PermissionCallback() {
            @Override
            public void onGranted() {
                // 权限已授予
            }

            @Override
            public void onDenied(String message) {
                runOnUiThread(() -> {
                    textStatus.setText("需要授权: " + message);
                    textStatus.setTextColor(getResources().getColor(R.color.accent_orange));
                });
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 恢复时刷新连接状态
        wearableManager.getConnectedDevice(new WearableManager.ConnectionCallback() {
            @Override
            public void onDeviceFound(Node node) {
                runOnUiThread(() -> {
                    if (!btnSend.isEnabled()) {
                        textStatus.setText(R.string.status_connected);
                        textStatus.setTextColor(getResources().getColor(R.color.accent_green));
                        textDeviceName.setText(node.name);
                        btnSend.setEnabled(true);
                        btnLaunchApp.setEnabled(true);
                        btnCheckApp.setEnabled(true);
                        checkPermission();
                    }
                });
            }

            @Override
            public void onNoDevice() {
                runOnUiThread(() -> {
                    if (btnSend.isEnabled()) {
                        btnSend.setEnabled(false);
                        btnLaunchApp.setEnabled(false);
                        btnCheckApp.setEnabled(false);
                    }
                });
            }

            @Override
            public void onServiceConnected() {}

            @Override
            public void onServiceDisconnected() {}

            @Override
            public void onError(String message) {}
        });
    }
}
