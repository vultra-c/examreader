package com.silenthong.kdreader;

import android.content.Context;
import android.util.Log;

import com.xiaomi.xms.wearable.Wearable;
import com.xiaomi.xms.wearable.auth.AuthApi;
import com.xiaomi.xms.wearable.auth.Permission;
import com.xiaomi.xms.wearable.message.MessageApi;
import com.xiaomi.xms.wearable.node.Node;
import com.xiaomi.xms.wearable.node.NodeApi;
import com.xiaomi.xms.wearable.service.OnServiceConnectionListener;
import com.xiaomi.xms.wearable.service.ServiceApi;
import com.xiaomi.xms.wearable.tasks.OnFailureListener;
import com.xiaomi.xms.wearable.tasks.OnSuccessListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.UUID;

/**
 * 考点阅读器 - 穿戴设备通信管理器
 * 封装 XMS Wearable SDK，管理手环连接、权限、消息发送
 *
 * 消息协议（安卓端 → 手环端）：
 * 单条消息：{"type":"content","title":"标题","content":"正文内容"}
 * 分片消息：
 *   起始：{"type":"start","id":"xxx","title":"标题","total":N}
 *   数据：{"type":"chunk","id":"xxx","index":i,"data":"片段内容"}
 *   结束：{"type":"end","id":"xxx"}
 */
public class WearableManager {

    private static final String TAG = "WearableManager";

    // 每个分片的最大字符数（蓝牙单次传输限制）
    private static final int MAX_CHUNK_SIZE = 2000;

    // 超过此字符数使用分片发送
    private static final int CHUNK_THRESHOLD = 2000;

    private static WearableManager instance;

    private final Context context;
    private final NodeApi nodeApi;
    private final MessageApi messageApi;
    private final AuthApi authApi;
    private final ServiceApi serviceApi;

    private Node currentNode = null;
    private boolean serviceConnected = false;

    // 回调接口
    public interface ConnectionCallback {
        void onDeviceFound(Node node);
        void onNoDevice();
        void onServiceConnected();
        void onServiceDisconnected();
        void onError(String message);
    }

    public interface AppCheckCallback {
        void onInstalled(boolean installed);
        void onError(String message);
    }

    public interface SendCallback {
        void onProgress(int current, int total, String message);
        void onSuccess();
        void onFailure(String message);
    }

    public interface PermissionCallback {
        void onGranted();
        void onDenied(String message);
    }

    private WearableManager(Context context) {
        this.context = context.getApplicationContext();
        this.nodeApi = Wearable.getNodeApi(this.context);
        this.messageApi = Wearable.getMessageApi(this.context);
        this.authApi = Wearable.getAuthApi(this.context);
        this.serviceApi = Wearable.getServiceApi(this.context);
    }

    public static synchronized WearableManager getInstance(Context context) {
        if (instance == null) {
            instance = new WearableManager(context);
        }
        return instance;
    }

    /**
     * 注册服务连接监听
     */
    public void registerServiceListener(final ConnectionCallback callback) {
        serviceApi.registerServiceConnectionListener(new OnServiceConnectionListener() {
            @Override
            public void onServiceConnected() {
                serviceConnected = true;
                if (callback != null) callback.onServiceConnected();
            }

            @Override
            public void onServiceDisconnected() {
                serviceConnected = false;
                if (callback != null) callback.onServiceDisconnected();
            }
        });
    }

    /**
     * 获取已连接的手环设备
     */
    public void getConnectedDevice(final ConnectionCallback callback) {
        nodeApi.getConnectedNodes().addOnSuccessListener(new OnSuccessListener<List<Node>>() {
            @Override
            public void onSuccess(List<Node> nodes) {
                if (nodes != null && !nodes.isEmpty()) {
                    currentNode = nodes.get(0);
                    if (callback != null) callback.onDeviceFound(currentNode);
                } else {
                    currentNode = null;
                    if (callback != null) callback.onNoDevice();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                Log.e(TAG, "getConnectedDevice failed", e);
                if (callback != null) callback.onError(e.getMessage());
            }
        });
    }

    /**
     * 检查手环端应用是否安装
     */
    public void checkAppInstalled(final AppCheckCallback callback) {
        if (currentNode == null) {
            if (callback != null) callback.onError("未连接到手环");
            return;
        }
        nodeApi.isWearAppInstalled(currentNode.id)
            .addOnSuccessListener(new OnSuccessListener<Boolean>() {
                @Override
                public void onSuccess(Boolean installed) {
                    if (callback != null) callback.onInstalled(installed);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception e) {
                    if (callback != null) callback.onError(e.getMessage());
                }
            });
    }

    /**
     * 启动手环端应用
     */
    public void launchWearApp(final ConnectionCallback callback) {
        if (currentNode == null) {
            if (callback != null) callback.onError("未连接到手环");
            return;
        }
        nodeApi.launchWearApp(currentNode.id, "/home")
            .addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Log.d(TAG, "launchWearApp success");
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception e) {
                    Log.e(TAG, "launchWearApp failed", e);
                    if (callback != null) callback.onError(e.getMessage());
                }
            });
    }

    /**
     * 请求设备管理权限
     */
    public void requestPermission(final PermissionCallback callback) {
        if (currentNode == null) {
            if (callback != null) callback.onDenied("未连接到手环");
            return;
        }
        authApi.requestPermission(currentNode.id, Permission.DEVICE_MANAGER)
            .addOnSuccessListener(new OnSuccessListener<Permission[]>() {
                @Override
                public void onSuccess(Permission[] permissions) {
                    if (callback != null) callback.onGranted();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception e) {
                    Log.e(TAG, "requestPermission failed", e);
                    if (callback != null) callback.onDenied(e.getMessage());
                }
            });
    }

    /**
     * 检查是否已授权
     */
    public void checkPermission(final PermissionCallback callback) {
        if (currentNode == null) {
            if (callback != null) callback.onDenied("未连接到手环");
            return;
        }
        authApi.checkPermission(currentNode.id, Permission.DEVICE_MANAGER)
            .addOnSuccessListener(new OnSuccessListener<Boolean>() {
                @Override
                public void onSuccess(Boolean granted) {
                    if (granted) {
                        if (callback != null) callback.onGranted();
                    } else {
                        // 未授权，自动请求
                        requestPermission(callback);
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception e) {
                    if (callback != null) callback.onDenied(e.getMessage());
                }
            });
    }

    /**
     * 发送考点内容到手环
     * @param title 考点标题
     * @param content 考点正文
     * @param callback 发送回调
     */
    public void sendContent(String title, String content, final SendCallback callback) {
        if (currentNode == null) {
            if (callback != null) callback.onFailure("未连接到手环");
            return;
        }

        if (content == null || content.isEmpty()) {
            if (callback != null) callback.onFailure("内容不能为空");
            return;
        }

        // 内容较短：单条消息发送
        if (content.length() <= CHUNK_THRESHOLD) {
            sendSingleContent(title, content, callback);
        } else {
            // 内容较长：分片发送
            sendChunkedContent(title, content, callback);
        }
    }

    /**
     * 单条消息发送
     */
    private void sendSingleContent(String title, String content, final SendCallback callback) {
        try {
            JSONObject msg = new JSONObject();
            msg.put("type", "content");
            msg.put("title", title != null ? title : "未命名");
            msg.put("content", content);

            final byte[] data = msg.toString().getBytes("UTF-8");
            if (callback != null) callback.onProgress(1, 1, "正在发送...");

            messageApi.sendMessage(currentNode.id, data)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "sendSingleContent success");
                        if (callback != null) callback.onSuccess();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        Log.e(TAG, "sendSingleContent failed", e);
                        if (callback != null) callback.onFailure(e.getMessage());
                    }
                });
        } catch (Exception e) {
            Log.e(TAG, "sendSingleContent error", e);
            if (callback != null) callback.onFailure(e.getMessage());
        }
    }

    /**
     * 分片发送
     */
    private void sendChunkedContent(String title, String content, final SendCallback callback) {
        final String chunkId = UUID.randomUUID().toString().replace("-", "");
        final int totalChunks = (int) Math.ceil((double) content.length() / MAX_CHUNK_SIZE);

        try {
            // 发送起始消息
            JSONObject startMsg = new JSONObject();
            startMsg.put("type", "start");
            startMsg.put("id", chunkId);
            startMsg.put("title", title != null ? title : "未命名");
            startMsg.put("total", totalChunks);

            final byte[] startData = startMsg.toString().getBytes("UTF-8");
            messageApi.sendMessage(currentNode.id, startData)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // 起始消息发送成功，开始发送数据分片
                        sendChunks(chunkId, content, totalChunks, 0, callback);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        if (callback != null) callback.onFailure(e.getMessage());
                    }
                });
        } catch (Exception e) {
            Log.e(TAG, "sendChunkedContent error", e);
            if (callback != null) callback.onFailure(e.getMessage());
        }
    }

    /**
     * 递归发送分片数据
     */
    private void sendChunks(final String chunkId, final String content,
                              final int totalChunks, final int currentIndex,
                              final SendCallback callback) {
        if (currentIndex >= totalChunks) {
            // 所有分片发送完毕，发送结束消息
            sendChunkEnd(chunkId, callback);
            return;
        }

        int start = currentIndex * MAX_CHUNK_SIZE;
        int end = Math.min(start + MAX_CHUNK_SIZE, content.length());
        String chunkData = content.substring(start, end);

        try {
            JSONObject chunkMsg = new JSONObject();
            chunkMsg.put("type", "chunk");
            chunkMsg.put("id", chunkId);
            chunkMsg.put("index", currentIndex);
            chunkMsg.put("data", chunkData);

            final byte[] data = chunkMsg.toString().getBytes("UTF-8");
            if (callback != null) {
                callback.onProgress(currentIndex + 1, totalChunks,
                    "正在发送 " + (currentIndex + 1) + "/" + totalChunks);
            }

            final int nextIndex = currentIndex + 1;
            messageApi.sendMessage(currentNode.id, data)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // 发送下一个分片
                        sendChunks(chunkId, content, totalChunks, nextIndex, callback);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        Log.e(TAG, "sendChunks failed at index " + currentIndex, e);
                        if (callback != null) callback.onFailure(
                            "发送第 " + (currentIndex + 1) + " 片失败: " + e.getMessage());
                    }
                });
        } catch (Exception e) {
            Log.e(TAG, "sendChunks error", e);
            if (callback != null) callback.onFailure(e.getMessage());
        }
    }

    /**
     * 发送分片结束消息
     */
    private void sendChunkEnd(String chunkId, final SendCallback callback) {
        try {
            JSONObject endMsg = new JSONObject();
            endMsg.put("type", "end");
            endMsg.put("id", chunkId);

            final byte[] data = endMsg.toString().getBytes("UTF-8");
            messageApi.sendMessage(currentNode.id, data)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "sendChunkEnd success");
                        if (callback != null) callback.onSuccess();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        Log.e(TAG, "sendChunkEnd failed", e);
                        if (callback != null) callback.onFailure(e.getMessage());
                    }
                });
        } catch (Exception e) {
            Log.e(TAG, "sendChunkEnd error", e);
            if (callback != null) callback.onFailure(e.getMessage());
        }
    }

    /**
     * 获取当前连接的设备
     */
    public Node getCurrentNode() {
        return currentNode;
    }

    /**
     * 是否已连接
     */
    public boolean isConnected() {
        return currentNode != null;
    }

    /**
     * 是否服务已连接
     */
    public boolean isServiceConnected() {
        return serviceConnected;
    }
}
