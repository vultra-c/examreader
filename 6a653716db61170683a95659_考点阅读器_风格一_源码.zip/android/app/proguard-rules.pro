# Keep XMS Wearable SDK classes
-keep class com.xiaomi.xms.wearable.** { *; }
-keepclassmembers class com.xiaomi.xms.wearable.** { *; }
