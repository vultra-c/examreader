/**
 * 考点阅读器 - 蓝牙通信管理模块
 * 基于 @system.interconnect 实现与安卓端的蓝牙通信
 *
 * 消息协议（安卓端 → 手环端）：
 * 单条消息：{"type":"content","title":"标题","content":"正文内容"}
 * 分片消息：
 *   起始：{"type":"start","id":"xxx","title":"标题","total":3}
 *   数据：{"type":"chunk","id":"xxx","index":0,"data":"内容片段1"}
 *   结束：{"type":"end","id":"xxx"}
 */
import interconnect from '@system.interconnect'
import dataManager from './dataManager.js'

// 连接状态常量
export const CONN_STATE = {
  IDLE: 'idle',             // 未初始化
  WAITING: 'waiting',       // 等待连接
  CONNECTED: 'connected',   // 已连接
  RECEIVING: 'receiving',   // 正在接收
  SUCCESS: 'success',       // 接收成功
  ERROR: 'error'            // 错误
}

// 内部状态
let conn = null
let currentState = CONN_STATE.IDLE
let callbacks = {}

// 分片接收缓存
let chunkCache = {}

/**
 * 注册状态变更回调
 * @param {string} name - 回调名称
 * @param {function} fn - 回调函数
 */
function on(name, fn) {
  callbacks[name] = fn
}

/**
 * 触发回调
 * @param {string} name - 回调名称
 * @param {*} data - 回调数据
 */
function emit(name, data) {
  if (callbacks[name]) {
    callbacks[name](data)
  }
}

/**
 * 设置状态并触发回调
 * @param {string} state - 新状态
 * @param {*} data - 附加数据
 */
function setState(state, data) {
  currentState = state
  emit('stateChange', { state, data })
}

/**
 * 获取当前状态
 */
function getState() {
  return currentState
}

/**
 * 初始化连接
 */
function init() {
  if (conn) {
    return
  }
  conn = interconnect.instance()

  conn.onopen = (res) => {
    console.log('interconnectManager: connection opened')
    setState(CONN_STATE.CONNECTED)
  }

  conn.onmessage = (res) => {
    console.log('interconnectManager: received message')
    handleMessage(res.data)
  }

  conn.onclose = (res) => {
    console.log('interconnectManager: connection closed')
    setState(CONN_STATE.WAITING)
  }

  conn.onerror = (res) => {
    console.log('interconnectManager: connection error, code=' + res.code + ', data=' + res.data)
    setState(CONN_STATE.ERROR, res.data || '连接错误')
  }

  // 检查连接状态
  conn.getReadyState({
    success: (res) => {
      if (res.status == 1) {
        setState(CONN_STATE.CONNECTED)
      } else {
        setState(CONN_STATE.WAITING)
      }
    },
    fail: () => {
      setState(CONN_STATE.WAITING)
    }
  })
}

/**
 * 处理接收到的消息
 * @param {*} data - 接收到的数据
 */
function handleMessage(data) {
  let msg = null
  try {
    if (typeof data === 'string') {
      msg = JSON.parse(data)
    } else if (typeof data === 'object') {
      msg = data
    } else {
      console.log('interconnectManager: unknown data type: ' + typeof data)
      return
    }
  } catch (e) {
    console.log('interconnectManager: parse message error: ' + e)
    return
  }

  if (!msg || !msg.type) {
    console.log('interconnectManager: invalid message, no type')
    return
  }

  switch (msg.type) {
    case 'content':
      handleSingleContent(msg)
      break
    case 'start':
      handleChunkStart(msg)
      break
    case 'chunk':
      handleChunkData(msg)
      break
    case 'end':
      handleChunkEnd(msg)
      break
    default:
      console.log('interconnectManager: unknown message type: ' + msg.type)
  }
}

/**
 * 处理单条完整内容
 */
function handleSingleContent(msg) {
  setState(CONN_STATE.RECEIVING, { title: msg.title })
  dataManager.addBluetoothContent(msg.title, msg.content).then((result) => {
    if (result) {
      setState(CONN_STATE.SUCCESS, { title: msg.title, count: 1 })
    } else {
      setState(CONN_STATE.ERROR, '保存失败')
    }
  })
}

/**
 * 处理分片起始消息
 */
function handleChunkStart(msg) {
  chunkCache[msg.id] = {
    title: msg.title,
    total: msg.total,
    chunks: []
  }
  setState(CONN_STATE.RECEIVING, { title: msg.title, progress: 0 })
}

/**
 * 处理分片数据消息
 */
function handleChunkData(msg) {
  const cache = chunkCache[msg.id]
  if (!cache) {
    console.log('interconnectManager: chunk cache not found for id=' + msg.id)
    return
  }
  cache.chunks[msg.index] = msg.data
  const progress = Math.round((cache.chunks.filter(c => c).length / cache.total) * 100)
  setState(CONN_STATE.RECEIVING, { title: cache.title, progress: progress })
}

/**
 * 处理分片结束消息
 */
function handleChunkEnd(msg) {
  const cache = chunkCache[msg.id]
  if (!cache) {
    console.log('interconnectManager: chunk cache not found for id=' + msg.id)
    return
  }

  // 拼接完整内容
  let fullContent = ''
  for (let i = 0; i < cache.total; i++) {
    if (cache.chunks[i]) {
      fullContent += cache.chunks[i]
    }
  }

  // 保存内容
  dataManager.addBluetoothContent(cache.title, fullContent).then((result) => {
    if (result) {
      setState(CONN_STATE.SUCCESS, { title: cache.title, count: 1 })
    } else {
      setState(CONN_STATE.ERROR, '保存失败')
    }
  })

  // 清理缓存
  delete chunkCache[msg.id]
}

/**
 * 发送消息到安卓端
 * @param {*} data - 要发送的数据
 * @returns {Promise<boolean>}
 */
function sendMessage(data) {
  return new Promise((resolve, reject) => {
    if (!conn) {
      reject(new Error('连接未初始化'))
      return
    }
    conn.send({
      data: data,
      success: () => resolve(true),
      fail: (res) => reject(res)
    })
  })
}

/**
 * 销毁连接
 */
function destroy() {
  conn = null
  chunkCache = {}
  callbacks = {}
  currentState = CONN_STATE.IDLE
}

export default {
  CONN_STATE,
  init,
  destroy,
  on,
  getState,
  sendMessage
}
