/**
 * 考点阅读器 - 数据管理器
 * 处理知识点树导航、分页、删除等功能
 */
import { knowledgeTree } from './knowledgeData.js'
import storage from '@system.storage'

const STORAGE_KEY_DELETED = 'KD_DELETED_CONTENT'
const STORAGE_KEY_INIT = 'KD_DATA_INIT'
const STORAGE_KEY_BT_CONTENTS = 'KD_BT_CONTENTS'

// 每页大约的字符数（考虑手环屏幕336x480，字号26px，每行约12字，每页约12行）
const CHARS_PER_PAGE = 155

// 生成唯一ID
function generateId() {
  return 'bt_' + Date.now() + '_' + Math.floor(Math.random() * 10000)
}

// 获取蓝牙接收内容列表
function getBluetoothContents() {
  return new Promise((resolve) => {
    storage.get({
      key: STORAGE_KEY_BT_CONTENTS,
      success: (data) => {
        if (data) {
          try {
            resolve(JSON.parse(data))
          } catch (e) {
            resolve([])
          }
        } else {
          resolve([])
        }
      },
      fail: () => resolve([])
    })
  })
}

// 保存蓝牙接收内容列表
function saveBluetoothContents(contents) {
  return new Promise((resolve) => {
    storage.set({
      key: STORAGE_KEY_BT_CONTENTS,
      value: JSON.stringify(contents),
      success: () => resolve(true),
      fail: () => resolve(false)
    })
  })
}

// 蓝牙内容缓存（供同步访问使用）
let btContentCache = null

// 刷新蓝牙内容缓存
function refreshBtCache() {
  return getBluetoothContents().then((contents) => {
    btContentCache = contents
    return contents
  })
}

// 获取已删除内容的ID集合
function getDeletedSet() {
  return new Promise((resolve) => {
    storage.get({
      key: STORAGE_KEY_DELETED,
      success: (data) => {
        if (data) {
          try {
            resolve(new Set(JSON.parse(data)))
          } catch (e) {
            resolve(new Set())
          }
        } else {
          resolve(new Set())
        }
      },
      fail: () => resolve(new Set())
    })
  })
}

// 保存已删除内容ID集合
function saveDeletedSet(deletedSet) {
  return new Promise((resolve) => {
    storage.set({
      key: STORAGE_KEY_DELETED,
      value: JSON.stringify(Array.from(deletedSet)),
      success: () => resolve(true),
      fail: () => resolve(false)
    })
  })
}

// 根据路径数组获取节点
// path: [0, 1, 2] 表示 tree[0].children[1].children[2]
function getNodeByPath(path) {
  if (!path || path.length === 0) return null
  let node = knowledgeTree
  for (let i = 0; i < path.length; i++) {
    const idx = path[i]
    if (i === 0) {
      node = knowledgeTree[idx]
    } else {
      if (node && node.children && node.children[idx]) {
        node = node.children[idx]
      } else {
        return null
      }
    }
  }
  return node
}

// 根据路径字符串获取节点
// pathStr: "0,1,2"
function getNodeByPathStr(pathStr) {
  if (!pathStr) return null
  const path = pathStr.split(',').map(s => parseInt(s))
  return getNodeByPath(path)
}

// 获取某路径下文件夹的可见子项（过滤已删除的）
function getVisibleChildren(pathStr) {
  return new Promise((resolve) => {
    const node = getNodeByPathStr(pathStr)
    if (!node || node.type !== 'folder' || !node.children) {
      resolve([])
      return
    }
    getDeletedSet().then((deletedSet) => {
      const visible = node.children.filter(child => !deletedSet.has(child.id))
      resolve(visible)
    })
  })
}

// 分页内容：将长文本按字符数切分为多页
// 尽量在换行符处断开，避免页面间内容断裂
function splitContentIntoPages(content) {
  if (!content) return ['无内容']
  const pages = []
  let current = ''
  let currentLen = 0
  const lines = content.split('\n')

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    // 如果当前行加上换行符会超过每页限制
    if (currentLen + line.length + 1 > CHARS_PER_PAGE && current.length > 0) {
      pages.push(current)
      current = line + '\n'
      currentLen = line.length + 1
    } else {
      current += line + '\n'
      currentLen += line.length + 1
    }
  }
  if (current.length > 0) {
    pages.push(current)
  }
  return pages.length > 0 ? pages : ['无内容']
}

export default {
  /**
   * 初始化数据（检查是否已初始化）
   */
  initData() {
    storage.get({
      key: STORAGE_KEY_INIT,
      success: (data) => {
        if (!data) {
          storage.set({ key: STORAGE_KEY_INIT, value: 'true' })
          storage.set({ key: STORAGE_KEY_DELETED, value: '[]' })
        }
      },
      fail: () => {
        storage.set({ key: STORAGE_KEY_INIT, value: 'true' })
        storage.set({ key: STORAGE_KEY_DELETED, value: '[]' })
      }
    })
  },

  /**
   * 获取顶层文件夹列表
   */
  getTopLevelFolders() {
    return new Promise((resolve) => {
      getDeletedSet().then((deletedSet) => {
        const visible = knowledgeTree.filter(child => !deletedSet.has(child.id))
        resolve(visible)
      })
    })
  },

  /**
   * 获取某路径下可见子项
   * pathStr: "0,1,2"
   */
  getVisibleChildren,

  /**
   * 根据路径字符串获取节点
   */
  getNodeByPathStr,

  /**
   * 获取节点的完整路径（从路径字符串）
   * 支持蓝牙内容路径 "bt:bt_xxx"
   */
  getNodeName(pathStr) {
    if (pathStr && pathStr.indexOf('bt:') === 0) {
      // 蓝牙内容：同步查找（从缓存）
      const btId = pathStr.substring(3)
      let name = ''
      if (btContentCache) {
        for (let i = 0; i < btContentCache.length; i++) {
          if (btContentCache[i].id === btId) {
            name = btContentCache[i].title
            break
          }
        }
      }
      return name
    }
    const node = getNodeByPathStr(pathStr)
    return node ? node.name : ''
  },

  /**
   * 获取内容节点的分页内容
   * pathStr: 指向content节点的路径，或 "bt:bt_xxx" 蓝牙内容
   */
  getReaderPages(pathStr) {
    return new Promise((resolve) => {
      // 蓝牙内容
      if (pathStr && pathStr.indexOf('bt:') === 0) {
        const btId = pathStr.substring(3)
        getBluetoothContents().then((contents) => {
          btContentCache = contents
          const item = contents.find(c => c.id === btId)
          if (item) {
            resolve(splitContentIntoPages(item.content))
          } else {
            resolve(['内容不存在'])
          }
        })
        return
      }
      const node = getNodeByPathStr(pathStr)
      if (!node || node.type !== 'content') {
        resolve(['无内容'])
        return
      }
      getDeletedSet().then((deletedSet) => {
        if (deletedSet.has(node.id)) {
          resolve(['该内容已被删除'])
          return
        }
        const pages = splitContentIntoPages(node.content)
        resolve(pages)
      })
    })
  },

  /**
   * 删除单个考点内容
   * pathStr: 指向content节点的路径，或 "bt:bt_xxx" 蓝牙内容
   */
  deleteContent(pathStr) {
    return new Promise((resolve) => {
      // 蓝牙内容删除
      if (pathStr && pathStr.indexOf('bt:') === 0) {
        const btId = pathStr.substring(3)
        getBluetoothContents().then((contents) => {
          const filtered = contents.filter(c => c.id !== btId)
          btContentCache = filtered
          saveBluetoothContents(filtered).then(() => resolve(true))
        })
        return
      }
      const node = getNodeByPathStr(pathStr)
      if (!node) {
        resolve(false)
        return
      }
      getDeletedSet().then((deletedSet) => {
        deletedSet.add(node.id)
        saveDeletedSet(deletedSet).then(() => resolve(true))
      })
    })
  },

  /**
   * 删除所有考点（包括蓝牙接收的内容）
   */
  deleteAll() {
    return new Promise((resolve) => {
      // 递归收集所有content的id
      const allIds = []
      function collect(node) {
        if (node.type === 'content') {
          allIds.push(node.id)
        } else if (node.type === 'folder' && node.children) {
          node.children.forEach(child => collect(child))
        }
      }
      knowledgeTree.forEach(node => collect(node))

      getDeletedSet().then((deletedSet) => {
        allIds.forEach(id => deletedSet.add(id))
        // 同时清空蓝牙内容
        btContentCache = []
        saveBluetoothContents([]).then(() => {
          saveDeletedSet(deletedSet).then(() => resolve(true))
        })
      })
    })
  },

  /**
   * 统计所有考点数量（包括蓝牙接收的内容）
   */
  getTotalContentCount() {
    return new Promise((resolve) => {
      getDeletedSet().then((deletedSet) => {
        let count = 0
        function countNodes(node) {
          if (node.type === 'content' && !deletedSet.has(node.id)) {
            count++
          } else if (node.type === 'folder' && node.children) {
            node.children.forEach(child => countNodes(child))
          }
        }
        knowledgeTree.forEach(node => countNodes(node))
        // 加上蓝牙接收内容数量
        getBluetoothContents().then((btContents) => {
          btContentCache = btContents
          count += btContents.length
          resolve(count)
        })
      })
    })
  },

  /**
   * 获取考点占用的存储大小（字节，包括蓝牙内容）
   */
  getContentStorageSize() {
    return new Promise((resolve) => {
      getDeletedSet().then((deletedSet) => {
        let size = 0
        function calcSize(node) {
          if (node.type === 'content' && !deletedSet.has(node.id)) {
            size += (node.content || '').length
            size += (node.name || '').length
          } else if (node.type === 'folder' && node.children) {
            node.children.forEach(child => calcSize(child))
          }
        }
        knowledgeTree.forEach(node => calcSize(node))
        // 加上蓝牙内容存储
        getBluetoothContents().then((btContents) => {
          btContentCache = btContents
          btContents.forEach(item => {
            size += (item.content || '').length
            size += (item.title || '').length
          })
          resolve(size)
        })
      })
    })
  },

  /**
   * 格式化文件大小
   */
  formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  },

  /**
   * 获取每页字符数
   */
  getCharsPerPage() {
    return CHARS_PER_PAGE
  },

  /**
   * 添加蓝牙接收的内容
   * @param {string} title - 标题
   * @param {string} content - 正文内容
   * @returns {Promise<boolean>}
   */
  addBluetoothContent(title, content) {
    return new Promise((resolve) => {
      getBluetoothContents().then((contents) => {
        const item = {
          id: generateId(),
          title: title || '未命名',
          content: content || '',
          timestamp: Date.now()
        }
        contents.unshift(item)
        btContentCache = contents
        saveBluetoothContents(contents).then(() => resolve(true))
      })
    })
  },

  /**
   * 获取所有蓝牙接收内容列表
   * @returns {Promise<Array>}
   */
  getBluetoothContents() {
    return getBluetoothContents().then((contents) => {
      btContentCache = contents
      return contents
    })
  },

  /**
   * 刷新蓝牙内容缓存
   */
  refreshBtCache() {
    return refreshBtCache()
  }
}
