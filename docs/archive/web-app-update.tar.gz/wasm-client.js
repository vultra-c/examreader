/**
 * WASM 客户端 — 封装 AstroBox-NG WASM 模块
 * 提供设备连接、第三方应用消息收发等能力
 *
 * 基于 BandBurg 项目的 wasm-client.js 改编
 * WASM 模块来自 AstroBox-NG (https://github.com/AstralSightStudios/AstroBox-NG)
 *
 * 事件接收机制：
 * 1. register_event_sink 注册回调，WASM 模块收到设备消息时调用
 *    回调可能收到 (eventType, payload) 或单个参数
 *    eventType 可能是 "interconnect-message"、"transport-packet" 等
 *    payload 是字符串（JSON 或 base64）
 *
 * 2. console.log 拦截作为后备方案，捕获 WASM 模块的日志输出
 *    匹配多种日志格式来提取消息内容
 */

class WasmClient {
  constructor() {
    this.wasmModule = null;
    this.isInitialized = false;
    this.eventCallbacks = new Map();
    this._eventSinkSetup = false;
    this._consoleCaptureSetup = false;
    this._rawEventLog = []; // 存储原始事件用于调试
  }

  async init() {
    if (this.isInitialized) return true;

    try {
      const wasmModule = await import('./wasm/astrobox_ng_wasm.js');
      await wasmModule.default();
      this.wasmModule = wasmModule;
      this.isInitialized = true;
      console.log('[WASM] 模块初始化成功');
      return true;
    } catch (error) {
      console.error('[WASM] 模块初始化失败:', error);
      return false;
    }
  }

  on(event, callback) {
    if (!this.eventCallbacks.has(event)) {
      this.eventCallbacks.set(event, []);
    }
    this.eventCallbacks.get(event).push(callback);
    this._setupEventSink();
  }

  off(event, callback) {
    const callbacks = this.eventCallbacks.get(event);
    if (callbacks) {
      const idx = callbacks.indexOf(callback);
      if (idx >= 0) callbacks.splice(idx, 1);
    }
  }

  emit(event, data) {
    const callbacks = this.eventCallbacks.get(event);
    if (callbacks) {
      callbacks.forEach(cb => {
        try { cb(data); } catch (e) { console.error('[WASM] 事件回调错误:', e); }
      });
    }
    // 通配符
    const wildcard = this.eventCallbacks.get('*');
    if (wildcard) {
      wildcard.forEach(cb => {
        try { cb({ event, ...data }); } catch (e) { console.error('[WASM] 通配回调错误:', e); }
      });
    }
  }

  _setupEventSink() {
    if (this._eventSinkSetup) return;

    if (this.wasmModule && this.wasmModule.register_event_sink) {
      try {
        // 注册事件接收回调
        // WASM 模块可能以多种格式调用此回调：
        //   (eventType: string, payload: string)
        //   (eventType: number, payload: string)
        //   (singleArg: string) — JSON 或原始数据
        //   (singleArg: object)
        this.wasmModule.register_event_sink((...args) => {
          // 记录原始参数用于调试
          const logEntry = {
            time: new Date().toISOString(),
            argCount: args.length,
            args: args.map(a => {
              if (typeof a === 'string') return a.substring(0, 500);
              if (a && typeof a === 'object') {
                try { return JSON.stringify(a).substring(0, 500); } catch (_) { return String(a); }
              }
              return String(a);
            })
          };
          this._rawEventLog.push(logEntry);
          if (this._rawEventLog.length > 100) this._rawEventLog.shift();

          console.log('[WASM] Event sink:', JSON.stringify(logEntry));

          // 尝试从参数中提取消息
          this._processEventSinkArgs(args);
        });
        console.log('[WASM] 事件接收器已注册');
      } catch (error) {
        console.error('[WASM] 注册事件接收器失败:', error);
      }
    }

    this._setupConsoleCapture();
    this._eventSinkSetup = true;
  }

  /**
   * 处理事件接收回调的参数
   * 支持多种可能的格式
   */
  _processEventSinkArgs(args) {
    if (args.length === 0) return;

    let eventType = null;
    let payload = null;

    if (args.length >= 2) {
      // (eventType, payload) 格式
      eventType = args[0];
      payload = args[1];
    } else if (args.length === 1) {
      // 单参数格式：可能是对象或字符串
      payload = args[0];
      // 如果是对象，尝试从中提取事件类型
      if (payload && typeof payload === 'object') {
        eventType = payload.event || payload.type || payload.eventType || null;
      }
    }

    // 尝试将 eventType 转为字符串
    if (eventType !== null && typeof eventType !== 'string') {
      eventType = String(eventType);
    }

    // 发射通用事件
    if (eventType) {
      this.emit(eventType, payload);
    }

    // 尝试从 payload 中提取第三方应用消息
    this._extractThirdPartyMessage(eventType, payload);
  }

  /**
   * 从事件数据中提取第三方应用消息
   * 手环通过 @system.interconnect 发送的消息格式为 {tag, ...data}
   */
  _extractThirdPartyMessage(eventType, payload) {
    let parsedData = null;
    let packageName = '';

    // 情况 1: payload 已经是对象
    if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
      // 检查是否包含 tag 字段（手环消息格式）
      if (payload.tag) {
        parsedData = payload;
      }
      // 检查是否是 {data: {...}, package_name: "..."} 格式
      else if (payload.data) {
        if (typeof payload.data === 'string') {
          try {
            parsedData = JSON.parse(payload.data);
          } catch (_) { /* 不是 JSON */ }
        } else if (typeof payload.data === 'object') {
          parsedData = payload.data;
        }
        packageName = payload.package_name || payload.packageName || '';
      }
      // 检查是否包含 message 字段
      else if (payload.message) {
        if (typeof payload.message === 'string') {
          try {
            parsedData = JSON.parse(payload.message);
          } catch (_) { /* 不是 JSON */ }
        }
      }
    }
    // 情况 2: payload 是字符串
    else if (typeof payload === 'string') {
      // 尝试直接解析为 JSON
      try {
        const parsed = JSON.parse(payload);
        if (parsed && typeof parsed === 'object') {
          if (parsed.tag) {
            parsedData = parsed;
          } else if (parsed.data) {
            // 可能是包装过的消息
            if (typeof parsed.data === 'string') {
              try {
                parsedData = JSON.parse(parsed.data);
              } catch (_) { parsedData = parsed; }
            } else {
              parsedData = parsed.data;
            }
            packageName = parsed.package_name || parsed.packageName || '';
          } else if (parsed.message) {
            if (typeof parsed.message === 'string') {
              try {
                parsedData = JSON.parse(parsed.message);
              } catch (_) { parsedData = parsed; }
            } else {
              parsedData = parsed.message;
            }
          }
        }
      } catch (_) {
        // 不是 JSON 字符串，可能是 base64 编码的数据
        // 尝试 base64 解码
        if (payload.length > 10 && /^[A-Za-z0-9+/=]+$/.test(payload)) {
          try {
            const decoded = atob(payload);
            try {
              parsedData = JSON.parse(decoded);
            } catch (_) {
              // 解码后不是 JSON
            }
          } catch (_) {
            // 不是有效的 base64
          }
        }
      }
    }

    // 如果成功解析出包含 tag 的消息，发射 thirdpartyapp_message 事件
    if (parsedData && parsedData.tag) {
      console.log('[WASM] 提取到第三方应用消息:', parsedData.tag, JSON.stringify(parsedData).substring(0, 200));
      this.emit('thirdpartyapp_message', {
        data: parsedData,
        package_name: packageName,
        rawEvent: eventType,
        timestamp: Date.now()
      });
    }
  }

  _setupConsoleCapture() {
    if (this._consoleCaptureSetup) return;

    const self = this;

    // 拦截 console.log 来捕获 WASM 模块输出的事件消息
    const origLog = console.log;
    const origInfo = console.info;

    console.log = function (...args) {
      origLog.apply(console, args);
      self._processWasmLog(args);
    };
    console.info = function (...args) {
      origInfo.apply(console, args);
      self._processWasmLog(args);
    };

    this._consoleCaptureSetup = true;
  }

  _processWasmLog(args) {
    if (!args || args.length === 0) return;

    // 将所有参数拼接成字符串
    const msg = args.map(a => {
      if (typeof a === 'string') return a;
      if (a && typeof a === 'object') {
        try { return JSON.stringify(a); } catch (_) { return String(a); }
      }
      return String(a);
    }).join(' ');

    // 跳过我们自己的日志
    if (msg.startsWith('[WASM]')) return;

    // 模式 1: "Received third-party app message from <pkg>: <data>"
    const patterns1 = [
      /Received third-party app message from\s+([^\s:]+):\s*(.+)/,
      /third-?party app message from\s+([^\s:]+):\s*(.+)/i,
    ];
    for (const pattern of patterns1) {
      const match = msg.match(pattern);
      if (match) {
        const packageName = match[1];
        const messageContent = match[2].trim();
        this._dispatchCapturedMessage(packageName, messageContent);
        return;
      }
    }

    // 模式 2: 包含 "interconnect" 和 JSON 的日志
    if (msg.toLowerCase().includes('interconnect')) {
      // 尝试提取 JSON 部分
      const jsonMatch = msg.match(/\{[^{}]*"tag"[^{}]*\}/);
      if (jsonMatch) {
        this._dispatchCapturedMessage('', jsonMatch[0]);
        return;
      }
    }

    // 模式 3: 日志中直接包含带 tag 的 JSON
    const jsonWithTag = msg.match(/\{[^{}]*"tag"\s*:\s*"([^"]+)"[^{}]*\}/);
    if (jsonWithTag) {
      this._dispatchCapturedMessage('', jsonWithTag[0]);
      return;
    }

    // 模式 4: 设备连接/断开事件
    if (msg.includes('Device connected') || msg.includes('设备已连接') || msg.includes('Connected to')) {
      this.emit('device_connected', { message: msg, timestamp: Date.now() });
    }
    if (msg.includes('Device disconnected') || msg.includes('设备已断开') || msg.includes('Disconnected')) {
      this.emit('device_disconnected', { message: msg, timestamp: Date.now() });
    }

    // 模式 5: 通用消息接收日志
    if (msg.toLowerCase().includes('received') && msg.toLowerCase().includes('message')) {
      // 尝试从消息中提取 JSON
      const jsonMatch = msg.match(/\{.+\}/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0]);
          if (parsed && (parsed.tag || parsed.data)) {
            this._dispatchCapturedMessage('', jsonMatch[0]);
            return;
          }
        } catch (_) { /* 不是有效 JSON */ }
      }
    }
  }

  /**
   * 将捕获到的消息分发为 thirdpartyapp_message 事件
   */
  _dispatchCapturedMessage(packageName, messageContent) {
    let parsedData = null;

    if (typeof messageContent === 'object') {
      parsedData = messageContent;
    } else if (typeof messageContent === 'string') {
      try {
        parsedData = JSON.parse(messageContent);
      } catch (e) {
        console.warn('[WASM] 无法解析消息内容:', messageContent.substring(0, 200));
        return;
      }
    }

    if (parsedData && typeof parsedData === 'object') {
      // 如果消息包含 data 字段且 data 是字符串，尝试进一步解析
      if (parsedData.data && typeof parsedData.data === 'string') {
        try {
          parsedData.data = JSON.parse(parsedData.data);
        } catch (_) { /* 保持原样 */ }
      }

      // 确保有 tag 字段
      const tag = parsedData.tag || (parsedData.data && parsedData.data.tag);
      if (tag) {
        console.log('[WASM] 捕获到消息:', tag);
        this.emit('thirdpartyapp_message', {
          data: parsedData.data || parsedData,
          package_name: packageName || parsedData.package_name || '',
          timestamp: Date.now()
        });
      }
    }
  }

  /**
   * 获取原始事件日志（用于调试）
   */
  getRawEventLog() {
    return this._rawEventLog;
  }

  async call(command, args = {}) {
    if (!this.isInitialized) {
      const ok = await this.init();
      if (!ok) throw new Error('WASM 模块未初始化');
    }
    if (!this.wasmModule) throw new Error('WASM 模块不可用');

    console.log(`[WASM] 调用: ${command}`, args);

    let result;
    switch (command) {
      case 'miwear_connect':
        result = await this.wasmModule.miwear_connect(
          args.name || '',
          args.addr || '',
          args.authkey || '',
          args.sar_version || args.sarVersion || 2,
          args.connect_type || args.connectType || 'SPP'
        );
        break;

      case 'miwear_disconnect':
        result = await this.wasmModule.miwear_disconnect(args.addr || '');
        break;

      case 'miwear_get_connected_devices':
        result = await this.wasmModule.miwear_get_connected_devices();
        break;

      case 'miwear_get_data':
        result = await this.wasmModule.miwear_get_data(
          args.addr || '',
          args.type || args.data_type || 'info'
        );
        break;

      case 'thirdpartyapp_get_list':
        result = await this.wasmModule.thirdpartyapp_get_list(args.addr || '');
        break;

      case 'thirdpartyapp_launch':
        result = await this.wasmModule.thirdpartyapp_launch(
          args.addr || '',
          args.package_name || args.packageName || '',
          args.page || ''
        );
        break;

      case 'thirdpartyapp_send_message':
        result = await this.wasmModule.thirdpartyapp_send_message(
          args.addr || '',
          args.package_name || args.packageName || '',
          args.data || ''
        );
        break;

      case 'thirdpartyapp_uninstall':
        result = await this.wasmModule.thirdpartyapp_uninstall(
          args.addr || '',
          args.package_name || args.packageName || ''
        );
        break;

      default:
        throw new Error(`不支持的命令: ${command}`);
    }

    console.log(`[WASM] ${command} 返回:`, result);
    return result;
  }
}

export default new WasmClient();
